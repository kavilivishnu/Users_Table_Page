import React from 'react';
import './App.css';
import Test from './Components/Test';

function App() {
  return (
    <div className="App">
      <h1>Users</h1>
      <Test />
    </div>
  );
}

export default App;
