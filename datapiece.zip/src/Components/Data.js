import React from 'react';

function Data({ data }) {
    const columns = data[0] && Object.keys(data[0]);
    return (
        <table cellPadding={0} cellSpacing={0}>
            <thead>
                <tr>{data[0] && columns.map((heading, id) =>
                    <th key={id}>
                        {heading}
                    </th>
                )}
                </tr>
            </thead>
            <tbody>
                {data.map((row, id) =>
                    <tr key={id}>
                        {
                            columns.map((column, id) =>
                                <td key={id}>
                                    {row[column]}
                                </td>
                            )
                        }
                    </tr>
                )}
            </tbody>
        </table>
    )
}

export default Data;
