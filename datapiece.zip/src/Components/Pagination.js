import React from 'react';

function Pagination() {
    return (
        <div>

        </div>
    )
}

export default Pagination;
