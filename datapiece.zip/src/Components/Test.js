import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Data from './Data';

function Test() {
    const [data, setData] = useState([]);
    const [search, setSearch] = useState("");

    useEffect(() => {
        axios.get("http://datapeace-storage.s3-us-west-2.amazonaws.com/dummy_data/users.json")
            .then((res) => {
                console.log(res)
                setData(res.data)

            }).catch((err) => {
                console.log(err)
            })
    }, [])

    function Find(rows) {
        const columns = rows[0] && Object.keys(rows[0]); // LINE 21
        return rows.filter((row) =>
            // some() is a metthod in arrays where the specified value is returned reagrdless the collection of segregated data if it matches with any of the expression.
            // whereas only filter functions scans all the data to get a signle value from expression which will increase the time complexity 
            // and will make the code look tidious.
            // Ex: If there would be no LINE 21, the code would be like below
            // return row.first_name.toLowercase().indexOf(search) > - 1 &&
            // row.last_name.toLowercase().indexOf(search) > - 1 &&
            // row.email_name.toLowercase().indexOf(search) > - 1 && etc...
            // LINE 21 will pull out all the key values from the rows and let us access them all at once with some() method which will 
            // also work as the alternative AND operator.
            columns.some(
                (column) => row[column].toString().toLowerCase().indexOf(search.toLowerCase()) > -1
            )
        );
    }
    return (
        <div>
            <div>
                <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div>
                <Data data={Find(data)} />
            </div>
        </div>
    )
}

export default Test;